"""
This module is responsible for creating folder
"""
import os


class CreateFolder:
    """
    This class holds:
    create_folder() method
    """
    def create_folder(self,input_list,cwd):
        """
        This method is reponsible to create a folder with given name
        if only there is no folder with that name
        """
        if len(input_list)>2 or len(input_list)<2:
            return "Entered wrong number of arguments in: "+str(input_list)

        new_path=str(cwd)+"/"+str(input_list[1])

        #checks if a folder exists with the given name or not"""
        if not os.path.exists(new_path):
            os.makedirs(new_path)
            return "A new folder is created with name:"+str(input_list[1])
        return "Already a folder is existed with the given name"
