"""
This module is responsible for login functionality
"""

import os
class Login:
    """
    This class holds:
    login() method
    logout() method
    """
    def login(self,input_list):
        """
        This method is responsible for login of the user
        provided with username and password
        """
        if len(input_list)>3 or len(input_list)<=2:
            return "Entered wrong number of arguments in: "+str(input_list)
        cwd=os.path.dirname(os.path.realpath(__file__))

        #user_data consists of user deatils in format of a list
        with open(cwd+"/user_data.txt",'r', encoding="utf8") as user_data:
            user_data = user_data.readlines()
        #print(user_data,"user data")

        if len(user_data)==0:
            return "Register first to login"

        user_count=0
        for name in user_data:
            user_count=user_count+1

            #Checks if given username exists in user_data or not
            if input_list[1] in name.split():
                user_log=open(cwd+"/user_logs.txt",'r', encoding="utf8").readlines()
                for user in user_log:
                    if input_list[1] in user.split():
                        return str(input_list[1]+" is already logged in")
                if input_list[2] != name.split()[1]:
                    return "Passowrd is incorrect"
            else:
                print(user_count,len(user_data))
                if user_count==len(user_data):
                    return "NO user registered with name "+str(input_list[1])

        #After successful login of the user user log will be created"""
        user_log=open(cwd+"/user_logs.txt",'a+', encoding="utf8")
        string=str(input_list[1])+"\n"
        user_log.write(string)

        return "User successfully logged in"

    def logout(self,user_name):
        """
        This method is reponsible for logging out the user from the server
        and also clears user log while logging out
        """
        cwd=os.path.dirname(os.path.realpath(__file__))
        user_log=open(cwd+"/user_logs.txt",'r', encoding="utf8")
        lines=user_log.readlines()
        output=[]
        for user in lines:
            if user_name+"\n" == user:
                continue
            output.append(user)

        user_log=open(cwd+"/user_logs.txt",'w', encoding="utf8")
        user_log.truncate(0)
        user_log.close()
        user_log=open(cwd+"/user_logs.txt",'w', encoding="utf8")
        for user in output:
            user_log.write(user)
        return str(user_name)+" logged out succesfully\n"
    