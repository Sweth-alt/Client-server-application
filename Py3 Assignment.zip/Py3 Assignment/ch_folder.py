"""
This moduke is responsible for changing folder
"""
import os

class ChangeFolder:
    """
    This class holds:
    ch_folder() method
    """
    def ch_folder(self, input_list, cwd, user):
        """
        This method is responsible for changing directory
        to the user from thier root directory
        """
        new_path=str(cwd)+"/"+str(input_list[1])
        split = os.getcwd().split("\\")
        if split[-1] == user and input_list[1] == "..":
            return "exists"
        return bool(os.path.isdir(new_path))
