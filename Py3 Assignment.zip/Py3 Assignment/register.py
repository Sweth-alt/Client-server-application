"""
This module is responsible for register functionality
"""
import os

class Register:
    """
    This class holds:
    register() method
    """
    def register(self,input_list):
        """
        This method is responsible for registering user into the server
        for given username and passowrd
        """
        if len(input_list)>3 or len(input_list)<=2:
            return "Entered wrong number of arguments in: "+str(input_list)
        cwd=os.path.dirname(os.path.realpath(__file__))
        user_data=open(cwd+"/user_data.txt",'r',encoding="utf8").readlines()
        for name in user_data:
            #checks if an user is already registerd or not"""
            if input_list[1].lower() in name.split():
                return "A user is already registered with username: "+str(input_list[1])

        string=str(input_list[1].lower())+" "+str(input_list[2])+"\n"
        with open(cwd+"/user_data.txt",'a+', encoding="utf8") as user_data:
            user_data.write(string)
        return "User successfully registered"
