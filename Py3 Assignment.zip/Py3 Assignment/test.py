"""
This module tests the functionalities
"""
import unittest
import os

from register import Register
from login import Login
from write_file import Write_file
from read_file import Read_file

class Test(unittest.TestCase):
    """
    This class holds all the test cases
    """
    def test_regiter(self):
        """This method is responsible to test register functionality"""
        input_commands = [
            ["register","myself","1234"],
            ["register","myself","1234"]
        ]
        feedbacks = [
            'User successfully registered',
            'A user is already registered with username: myself'
        ]
        answers = []
        for command in input_commands:
            answers.append(Register.register(self,command))
        self.assertListEqual(answers, feedbacks)

    def test_login(self):
        """This method is responsible to test login functionality"""
        Register.register(self,["register","me","1234"])
        input_commands = [
            ["login","me","1234"],
            ["login","me","1234"]
        ]
        feedbacks = [
            'User successfully logged in',
            'me is already logged in'
        ]
        answers = []
        for command in input_commands:
            answers.append(Login.login(self,command))
        self.assertListEqual(answers, feedbacks)

    def test_write_file(self):
        """This method is responsible to test writing into a file functionality"""
        input_commands = [["write_file","sample.txt","hello world"],["write_file","sample.txt"]]
        feedback = ["Successfully written the contents","Successfully cleared the contents"]
        answers = []
        for command in input_commands:
            answers.append(Write_file.write_file(self,command,os.getcwd()))
        self.assertListEqual(answers, feedback)

    def test_read_file(self):
        """This method is responsible to test reading a file functionality"""
        Write_file.write_file(self,["write_file","sample.txt"],os.getcwd())
        input_commands = ["read_file","sample.txt"]
        feedback = ["File is empty"]
        answers=[]
        answers.append(Read_file.read_file(self,input_commands,os.getcwd()))
        self.assertListEqual(answers, feedback)

if __name__ == '__main__':
    unittest.main()
